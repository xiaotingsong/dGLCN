main.py:  It contains the training, testing, and interpretability output of the model.
utils.py:  It contains some predefined functions, including graph construction, data pre-processing, etc.
The "data" folder should have contained the ADNI datasets we used in the paper, but it is private and unpublished data. Please understand that we have no authority to disclose it.