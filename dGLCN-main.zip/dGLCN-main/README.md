# MICCAI_2022
The codes are from MICCAI 2022, "Dual-graph Learning Convolutional Networks for Interpretable Alzheimer’s Disease Diagnosis"
